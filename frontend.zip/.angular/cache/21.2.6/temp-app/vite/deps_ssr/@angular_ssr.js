import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRendering,
  setAngularAppEngineManifest,
  setAngularAppManifest,
  withAppShell,
  withRoutes
} from "./chunk-HGKQ7PF5.js";
import "./chunk-GA7FTU65.js";
import "./chunk-2C3CWNWP.js";
import "./chunk-32XWVS6U.js";
import "./chunk-V6FQZLEF.js";
import "./chunk-2MJTEFOU.js";
import "./chunk-5XWRNPOG.js";
import "./chunk-C27DBZK2.js";
import "./chunk-WC4PITUE.js";
import "./chunk-2UVUUPPC.js";
import "./chunk-K54IFBYX.js";
import "./chunk-6DU2HRTW.js";
export {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRendering,
  withAppShell,
  withRoutes,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
